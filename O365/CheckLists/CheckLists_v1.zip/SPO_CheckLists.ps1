﻿param
(
    [parameter(Mandatory=$true)]
    [string]$MossListsFile,

    [parameter(Mandatory=$true)]
    [string]$O365SiteUrl,
    
    [parameter(Mandatory=$true)]
    [string]$UserName,

    [parameter(Mandatory=$true)]
    [string]$UserPassword
)

if ($PSVersionTable.PSVersion -gt [Version]"3.0") {
  powershell -Version 3 -File $MyInvocation.MyCommand.Definition $MossListsFile $O365SiteUrl $UserName $UserPassword
  exit
}

$Password = $UserPassword |ConvertTo-SecureString -AsPlainText -force
Write-Host "Load CSOM libraries" -ForegroundColor Black -BackgroundColor Yellow
$Dir = Split-Path -parent $MyInvocation.MyCommand.Path
$DllsDir = $Dir+"\DLL"
Add-Type –Path "$($DllsDir)\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "$($DllsDir)\Microsoft.SharePoint.Client.Runtime.dll"
Write-Host "CSOM libraries loaded successfully" -ForegroundColor Black -BackgroundColor Green

Write-Host "Authenticate to SharePoint Online Tenant site $O365SiteUrl and get ClientContext object" -ForegroundColor Black -BackgroundColor Yellow  
$context = New-Object Microsoft.SharePoint.Client.ClientContext($O365SiteUrl) 
$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Username, $Password)
 
$context.Credentials = $credentials 
$context.RequestTimeOut = 5000 * 60 * 10;
$web = $context.Web
$site = $context.Site 
$context.Load($web)
$context.Load($site)
try
{
  $context.ExecuteQuery()
  Write-Host "  Authenticateed to SharePoint Online Tenant site $O365SiteUrl and get ClientContext object succeefully" -ForegroundColor Black -BackgroundColor Green
}
catch
{
  Write-Host "  Not able to authenticateed to SharePoint Online $_.Exception.Message" -ForegroundColor Black -BackgroundColor Red
  return
}

$SiteName = $web.Title
$SiteName = $SiteName.Replace(' ','_')

$MissedLists = @()
$OkLists = @()
$MissedItemsLists = @()
$NotMatchedLastModDateLists = @()

$MossLists = Import-Csv -Path $MossListsFile
Write-Host "Loaded $($MossLists.Count) lists from $($MossListsFile)"

foreach ($mosslist in $MossLists)
{
    $O365SiteUrl = $O365SiteUrl.TrimEnd('/')+"/"
    $mossWeb = $mosslist.WebUrl
    $match=$mossWeb -match "https?://.*?/"
    $o365Web = ($mossWeb).Replace($Matches[0],$O365SiteUrl)
    $context = New-Object Microsoft.SharePoint.Client.ClientContext($o365Web)  
    $context.Credentials = $credentials
    [Microsoft.SharePoint.Client.Web]$web = $context.Web
    [Microsoft.SharePoint.Client.List]$list = $web.Lists.GetByTitle($mosslist.Title)
    $context.Load($list)
    try
    {
         $context.ExecuteQuery()
         $listobj=New-Object -TypeName PSObject
         $listobj| Add-Member -Name "WebURL" -MemberType Noteproperty -Value $o365Web
         $listobj| Add-Member -Name "Title" -MemberType Noteproperty -Value $list.Title
         $listobj| Add-Member -Name "ItemCount" -MemberType NoteProperty -Value $list.ItemCount
         $listobj| Add-Member -Name "LastModified" -MemberType NoteProperty -Value $list.LastItemModifiedDate

         if(($list.ItemCount -eq $mosslist.ItemCount) -and ($list.LastItemModifiedDate -eq $mosslist.LastItemModifiedDate))
         {
            $OkLists += $listobj
            
         }
         else
         {
            if($list.ItemCount -lt $mosslist.ItemCount)
            {
                $listobj| Add-Member -Name "MossItemCount" -MemberType NoteProperty -Value $mosslist.ItemCount
                $listobj| Add-Member -Name "MissedItemCount" -MemberType NoteProperty -Value ($mosslist.ItemCount-$list.ItemCount)
                $MissedItemsLists += $listobj    
            }
            if($list.LastItemModifiedDate -ne $mosslist.LastModified)
            {
                $listobj| Add-Member -Name "MossLastModified" -MemberType NoteProperty -Value $mosslist.LastModified
                $NotMatchedLastModDateLists += $listobj    
            }
         }
    }
    catch
    {
        $MissedLists += $mosslist
    }
    
}

Write-Host "MissedItemsLists:"
$MissedItemsLists|Format-Table -AutoSize -Wrap -Property WebUrl,Title,ItemCount,MossItemCount,MissedItemCount
Write-Host
Write-Host "NotMatchedLastModDateLists:"
$NotMatchedLastModDateLists|Format-Table -AutoSize -Wrap -Property WebUrl,Title,LastModified,MossLastModified
Write-Host
Write-Host "MissedLists:"
$MissedLists|Format-Table -AutoSize -Wrap -Property Url,Title
Write-Host
Write-Host "OKLists:"
$OKLists|Format-Table -AutoSize -Wrap -Property WebUrl,Title,ItemCount,LastModified

#For Output file generation
$SaveDir = Split-Path -parent $MyInvocation.MyCommand.Path

$MissedItemsListsReport = $SiteName + "_ListsWithMissedItems.csv"
$LastModifiedListsReport = $SiteName + "_ListsWithNotMatchedLastModifiedDate.csv"
$MissedListsReport = $SiteName + "_MissedLists.csv"
$OutputReports = @($MissedItemsListsReport,$LastModifiedListsReport,$MissedListsReport)
foreach ($report in $OutputReports)
{
    $OutputFilePath = $SaveDir+"\"+$report
    if (Test-Path $OutputFilePath)
     {
        Remove-Item $OutputFilePath
     }

     switch -Wildcard ($report)
     {
        "*ListsWithMissedItems*" {$MissedItemsLists|Export-Csv $OutputFilePath -NoTypeInformation;Write-Host "Output file saved at: $OutputFilePath"}
        "*ListsWithNotMatchedLastModifiedDate*" {$NotMatchedLastModDateLists|Export-Csv $OutputFilePath -NoTypeInformation;Write-Host "Output file saved at: $OutputFilePath"}
        "*MissedLists*" {$MissedLists|Export-Csv $OutputFilePath -NoTypeInformation;Write-Host "Output file saved at: $OutputFilePath"}
        default {"Parameter is incorrect"}
     }
}



